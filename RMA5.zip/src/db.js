// db.js
import { DB_URL } from './config.js';
import pkg from 'pg';
const { Client } = pkg;

export const queryDB = async (text, params) => {
  const client = new Client({ connectionString: "postgresql://RedMedicalAdvisor_owner:LUrkXxPQ8N9l@ep-hidden-mountain-a6pxs14l.us-west-2.aws.neon.tech/RedMedicalAdvisor?sslmode=require" });
  await client.connect(); // Conectar antes de ejecutar la consulta

  try {
    const res = await client.query(text, params);
    return res.rows;
  } catch (err) {
    console.error('Error en la consulta:', err);
    throw err; // Re-lanza el error para manejarlo más arriba si es necesario
  } finally {
    await client.end(); // Asegúrate de cerrar la conexión
  }
};
