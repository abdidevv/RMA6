import { queryDB } from '../../db.js';

export async function GET() {
  try {
    const usuarios = await queryDB('SELECT * FROM usuarios');
    return new Response(JSON.stringify(usuarios), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*', // Ajusta esto según tus necesidades de CORS
      },
    });
  } catch (err) {
    console.error('Error al obtener usuarios:', err);
    return new Response(JSON.stringify({ error: 'Error en la consulta', details: err.message }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

export async function POST(req) {
  try {
    const text = await req.text(); // Cambia esto a text
    const data = JSON.parse(text);
    const { nombre, apellido_paterno, apellido_materno, correo, contraseña } = await req.json(); // Asume que envías estos campos en el cuerpo

    // Validar datos
    if (!nombre || !apellido_paterno || !apellido_materno || !correo || !contraseña) {
      return new Response(JSON.stringify({ error: 'Faltan datos requeridos' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Inserta el nuevo usuario en la base de datos
    const result = await queryDB(
      'INSERT INTO usuarios (usuario_nombre, usuario_apellido_paterno, usuario_apellido_materno, usuario_correo, usuario_contraseña) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [nombre, apellido_paterno, apellido_materno, correo, contraseña]
    );

    return new Response(JSON.stringify(result), {
      status: 201,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('Error al crear usuario:', err);
    return new Response(JSON.stringify({ error: 'Error al crear usuario', details: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}